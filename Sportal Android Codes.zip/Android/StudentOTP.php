  <?php
    
    require_once 'user.php';
    
    $enrol = "";
        
    if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
     $userObject = new User();
    
     if(!empty($enrol))
     {
     
        $json_mobile = $userObject->OTPEnrolCheck($enrol);
        
        echo json_encode($json_mobile);
     
     }