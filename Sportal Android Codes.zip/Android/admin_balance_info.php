<?php
    
    require_once 'user.php';
    
    $enrol = "";

        
    if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
    
    
    $userObject = new User();
    
    // Student Info
    
    if(!empty($enrol)){
        
        
        $json_student_details = $userObject->student_payment_details($enrol);
        
        echo json_encode($json_student_details);
        
    }
    
    ?>