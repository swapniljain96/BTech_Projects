<?php
    
    require_once 'user.php';
    
    $image       = "";
    
    $image_id    = 0;

        
    if(isset($_POST['image'])){
        
        $image = $_POST['image'];
        
    }
    
    $userObject = new User();
    
    $image_id   = $userObject->gallery_imageid();
    $name       = "gallery_img"."$image_id";
    $image_url  = "gallery_images/".$name.".JPG";
    
    $decodedimage = base64_decode("$image");
    
    // Gallery
    
        $json_gallery = $userObject->gallery_details($decodedimage, $image_url);
        
        echo json_encode($json_gallery);
        
    
    ?>