<?php
    
    require_once 'user.php';
    
    $game  = "";
    $date  = "";
    $time  = "";
    $venue = "";
    
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
    if(isset($_POST['date'])){
        
        $date = $_POST['date'];
        
    }
    
    if(isset($_POST['time'])){
        
        $time = $_POST['time'];
        
    }
    
    if(isset($_POST['venue'])){
        
        $venue = $_POST['venue'];
        
    }
    
    $userObject = new User();
    
    // Student Info
    
    if(!empty($game) && !empty($date) && !empty($time) && !empty($venue)){
        
        
        $json_gameinfo = $userObject->games_schedule($game, $date, $time, $venue);
        
        echo json_encode($json_gameinfo);
        
    }
    
    ?>