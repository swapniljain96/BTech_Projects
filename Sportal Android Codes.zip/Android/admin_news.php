<?php
    
    require_once 'user.php';
    
    $image       = "";
    $heading     = "";
    $description = "";
    $time        = "";
    
    $image_id    = 0;

        
    if(isset($_POST['image'])){
        
        $image = $_POST['image'];
        
    }
    
    if(isset($_POST['heading'])){
        
        $heading = $_POST['heading'];
        
    }
    
    if(isset($_POST['description'])){
        
        $description = $_POST['description'];
        
    }
    
    if(isset($_POST['time'])){
        
        $time = $_POST['time'];
        
    }
    
    $userObject = new User();
    
    $image_id   = $userObject->news_imageid();
    $name       = "news_img"."$image_id";
    $image_url  = "news_images/".$name.".JPG";
    
    $decodedimage = base64_decode("$image");
    
    // News
    
    if(!empty($heading) && !empty($description)){
        
        
        $json_news = $userObject->news_details($decodedimage, $image_url, $heading, $description, $time);
        
        echo json_encode($json_news);
        
    }
    
    ?>