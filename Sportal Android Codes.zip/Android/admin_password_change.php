 <?php
    
    require_once 'user.php';
    
    $c_pass   = "";
    $n_pass   = "";
    $username = "";

    if(isset($_POST['c_pass'])){
        
        $c_pass = $_POST['c_pass'];
        
    }
    
    if(isset($_POST['n_pass'])){
        
        $n_pass = $_POST['n_pass'];
        
    }
    
    if(isset($_POST['username'])){
        
        $username = $_POST['username'];
        
    }
    
     $userObject = new User();
     
  //Login
    
   if(!empty($c_pass) && !empty($n_pass)) {
       
        $hashed_cpassword = md5($c_pass);
        $hashed_npassword = md5($n_pass);
        
        $json_array = $userObject->AdminPassChange($hashed_cpassword, $hashed_npassword, $username);
        
        echo json_encode($json_array);
    }