<?php
    
    require_once 'user.php';
    
    $game = "";
    $status = "";
        
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
    if(isset($_POST['status'])){
        
        $status = $_POST['status'];
        
    }
    
    $userObject = new User();
    
    // Student Info
    
        $json_balance_status = $userObject->fetch_balance_status($game, $status);
        
        echo json_encode($json_balance_status);
    
    ?>