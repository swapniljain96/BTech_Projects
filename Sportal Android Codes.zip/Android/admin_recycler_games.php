<?php
    
    require_once 'user.php';
    
    $game = "";
    
    
    $userObject = new User();
    
    // Student Info
    
        $json_gameinfo = $userObject->recycler_game($game);
        
        echo json_encode($json_gameinfo);
    
    ?>