<?php
    
    require_once 'user.php';
    
    $enrol = "";
    $studentname  = "";
    $fathername   = "";
    $password     = "";
    $mobileno     = "";
    $emailid      = "";
    $gender       = "";
    $course       = "";
    $year         = "";
    $section      = "";
    $game1        = "";
    $game2        = "";
    $game3        = "";
        
    if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
    if(isset($_POST['studentname'])){
        
        $studentname = $_POST['studentname'];
        
    }

    if(isset($_POST['fathername'])){
        
        $fathername = $_POST['fathername'];
        
    }

    if(isset($_POST['password'])){
        
        $password = $_POST['password'];
        
    }

    if(isset($_POST['mobileno'])){
        
        $mobileno = $_POST['mobileno'];
        
    }

    if(isset($_POST['emailid'])){
        
        $emailid = $_POST['emailid'];
        
    }

    if(isset($_POST['gender'])){

        $gender = $_POST['gender'];
        
    }

    if(isset($_POST['course'])){
        
        $course = $_POST['course'];
        
    }

    if(isset($_POST['year'])){
        
        $year = $_POST['year'];
        
    }
    
    if(isset($_POST['section'])){
        
        $section = $_POST['section'];
        
    }

    if(isset($_POST['game1'])){
        
        $game1 = $_POST['game1'];
        
    }
    
    
    if(isset($_POST['game2'])){
        
        $game2 = $_POST['game2'];
        
    }


    if(isset($_POST['game3'])){
        
        $game3 = $_POST['game3'];
        
    }
    
    $fees = 0;
    $amount = 0;
    

    $userObject = new User();
    
    //amount
    if($fees == 0)
    {
         $amount = $userObject->calc_fees($game1, $game2, $game3);
    }
    
    // Registration
       if(!empty($enrol) && !empty($studentname) && !empty($password) && ($amount!=0)){
           
        $hashed_password = md5($password);
        
        $json_registration = $userObject->createNewRegisterUser($enrol, $studentname, $fathername, $hashed_password, $mobileno, $emailid, $gender, $course, $year, $section, $game1, $game2, $game3, $amount);
        
        echo json_encode($json_registration);
    
        }
    ?>