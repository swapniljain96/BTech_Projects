<?php
    
    require_once 'user.php';
    
    $game    = "";
    $winner  = "";
    
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
    if(isset($_POST['winner'])){
        
        $winner = $_POST['winner'];
        
    }
    
    
    $userObject = new User();
    
    // Student Info
    
    if(!empty($game) && !empty($winner)){
        
        
        $json_result = $userObject->AdminResults($game, $winner);
        
        echo json_encode($json_result);
        
    }
    
    ?>