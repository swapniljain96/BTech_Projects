<?php
    
    require_once 'user.php';
    
    $game = "";
    $fees = "";
        
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
    if(isset($_POST['fees'])){
        
        $fees = $_POST['fees'];
        
    }
    
    
    
    $userObject = new User();
    
    // Student Info
    
    if(!empty($game) && !empty($fees)){
        
        
        $json_gameinfo = $userObject->add_games($game, $fees);
        
        echo json_encode($json_gameinfo);
        
    }
    
    if(!empty($game) && empty($fees))
    {
     
        $json_gamedel = $userObject->del_games($game);
        
        echo json_encode($json_gamedel);
        
    }
    ?>