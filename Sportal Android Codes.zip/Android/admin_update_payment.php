<?php
    
    require_once 'user.php';
    
    $enrol          = "";
    $fees_status    = "";
    $payment_mode   = "";
    
     if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
    if(isset($_POST['fees_status'])){
        
        $fees_status = $_POST['fees_status'];
        
    }


    if(isset($_POST['payment_mode'])){
        
        $payment_mode = $_POST['payment_mode'];
        
    }
    
    $userObject = new User();
    
    // Updating Payment
       if(!empty($fees_status)){
        
        $json_upd_pay = $userObject->Update_Payment($enrol, $fees_status, $payment_mode);
        
        echo json_encode($json_upd_pay);
    
        }
    ?>