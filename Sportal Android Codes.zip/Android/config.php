<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "id4712255_techion");
    define("DB_PASSWORD", "tronlegacy");
    define("DB_NAME", "id4712255_sportal");
    ?>