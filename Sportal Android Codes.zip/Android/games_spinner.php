<?php
		require_once 'user.php';
		
		$game = "";
        
        if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
        }
		
		$userObject = new User();
		   
        $json_games = $userObject->spinner();
        
        echo json_encode($json_games);
        
?>