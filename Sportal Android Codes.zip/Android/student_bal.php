 <?php
    
    require_once 'user.php';
    
    $enrol = "";
        
    if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
     $userObject = new User();
     
        //My Games
    
     if(!empty($enrol))
     {
     
        $json_array = $userObject->StudentBalance($enrol);
        
        echo json_encode($json_array);
     
     }