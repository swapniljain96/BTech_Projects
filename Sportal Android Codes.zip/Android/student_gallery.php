 <?php
    
    require_once 'user.php';
    
    $game = "";
        
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
     $userObject = new User();
     
  //Gallery
    
    $json_gallery = $userObject->Gallery();
        
        echo json_encode($json_gallery);
        
?>