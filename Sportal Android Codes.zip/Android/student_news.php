 <?php
    
    require_once 'user.php';
    
    $game = "";
        
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
     $userObject = new User();
     
  //Student News
    
    $json_news = $userObject->StudentNews();
        
        echo json_encode($json_news);
        
?>