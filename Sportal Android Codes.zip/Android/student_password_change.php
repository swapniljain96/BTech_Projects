 <?php
    
    require_once 'user.php';
    
    $c_pass   = "";
    $n_pass   = "";
    $enrol = "";

    if(isset($_POST['c_pass'])){
        
        $c_pass = $_POST['c_pass'];
        
    }
    
    if(isset($_POST['n_pass'])){
        
        $n_pass = $_POST['n_pass'];
        
    }
    
    if(isset($_POST['enrol'])){
        
        $enrol = $_POST['enrol'];
        
    }
    
     $userObject = new User();
     
  //Change Password
    
   if(!empty($c_pass) && !empty($n_pass)) {
       
        $hashed_cpassword = md5($c_pass);
        $hashed_npassword = md5($n_pass);
        
        $json_array = $userObject->StudentPassChange($hashed_cpassword, $hashed_npassword, $enrol);
        
        echo json_encode($json_array);
    }