 <?php
    
    require_once 'user.php';
    
    $game = "";
        
    if(isset($_POST['game'])){
        
        $game = $_POST['game'];
        
    }
    
     $userObject = new User();
     
  //Student News
    
    $json_result = $userObject->StudentResult();
        
        echo json_encode($json_result);
        
?>