<?php
    
    require_once 'user.php';
    
    $game = "";
    
    
    $userObject = new User();
    
    // Student Info
    
        $json_gameinfo = $userObject->upcoming_games($game);
        
        echo json_encode($json_gameinfo);
    
    ?>