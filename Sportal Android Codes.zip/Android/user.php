<?php
    
    include_once 'db-connect.php';
    
    class User{
        
        private $db;
        
        private $db_table = "student_details";
        private $db_table2 = "student_games";
        private $db_table3 = "games_details";
        private $db_table4 = "admin_login";
        private $db_table5 = "match_news";
        private $db_table6 = "match_result";
        private $db_table7 = "gallery";
        
        public function __construct(){
            $this->db = new DbConnect();
        }
        
        //Admin Login Check
        
         public function isAdminLoginExist($username, $password){
            
            $query = "select * from ".$this->db_table4." where username = '$username' AND password = '$password'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                return true;
                
            }
            
            mysqli_close($this->db->getDb());
            
            return false;
            
        }
        
        //Admin Login
        
        public function loginAdmin($username, $password){
            
            $json = array();
            
            $canAdminLogin = $this->isAdminLoginExist($username, $password);
            
            if($canAdminLogin){
                
                $query  = "select admin_name from ".$this->db_table4." where username = '$username'";
            
                $result = mysqli_query($this->db->getDb(), $query);
                
                $row    = mysqli_fetch_assoc($result);
                
                $json['success'] = 1;
                $json['message'] = "Successfully Logged In";
                $json['name']    = $row['admin_name'];     
 
                
            }else{
                $json['success'] = 0;
                $json['message'] = "Invalid Username Or Password";
            }
            
            return $json;
        }
        
        //Calculate Games Fees
        
        public function calc_fees($game1, $game2, $game3)
        {
            $json = 0;
            
            if($game1 != ' ')
            {
                $query = "select fees from ".$this->db_table3." where game_name = '$game1'";
                $result = mysqli_query($this->db->getDb(), $query);
                $row = mysqli_fetch_assoc($result);
                $json = $json + $row['fees'];
            }
            
            if($game2 != ' ')
            {
                $query = "select fees from ".$this->db_table3." where game_name = '$game2'";
                $result = mysqli_query($this->db->getDb(), $query);
                $row = mysqli_fetch_assoc($result);
                $json = $json + $row['fees'];
            }
            
            if($game3 != ' ')
            {
                $query = "select fees from ".$this->db_table3." where game_name = '$game3'";
                $result = mysqli_query($this->db->getDb(), $query);
                $row = mysqli_fetch_assoc($result);
                $json = $json + $row['fees'];
            }
            
            return $json;
            
        }
        
        //Registration Enrol Check
        
        public function isEnrolExist($enrol){
            
            $query = "select * from ".$this->db_table." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
               
                return true;
            }
            
            return false;
        }
        
        //Registration Of Students
        
        public function createNewRegisterUser($enrol, $studentname, $fathername, $password, $mobileno, $emailid, $gender, $course, $year, $section, $game1, $game2, $game3, $amount){
            
            
            $isExisting = $this->isEnrolExist($enrol);
            
            if($isExisting){
                
                $json['success'] = 0;
                $json['message'] = "Error : Enrolment No. Already Exists";
            }
            
            else{
                
                $query = "insert into ".$this->db_table." (enrol_no, student_name, father_name, gender, course, year, section, phone_no, email_id, password, valid) values ('$enrol', '$studentname', '$fathername', '$gender', '$course', '$year', '$section','$mobileno', '$emailid', '$password', '0')";

                $query2 ="insert into ".$this->db_table2." (enrol_no, game_1, game_2, game_3, fees, fees_status, payment_mode) values ('$enrol', '$game1', '$game2', '$game3','$amount', 'Unpaid', '')";

                $inserted = mysqli_query($this->db->getDb(), $query);
                $inserted2 = mysqli_query($this->db->getDb(), $query2);

                if(($inserted == 1) && ($inserted2 == 1)){
                    
                    $json['success'] = 1;
                    $json['message'] = "Student Successfully Registered";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Registration Unsuccessful";
                    
                }
                
            }
            
            return $json;
        }
     
        //Student Payment And Student Details
        
         public function student_payment_details($enrol)
     {
 
         $isExisting = $this->isEnrolExist($enrol);
            
            if($isExisting){
                
                $qry1 = "SELECT * FROM ".$this->db_table2." where enrol_no = '$enrol'";
                $qry2 = "SELECT * FROM ".$this->db_table." where enrol_no = '$enrol'";
                
                $stmt1 = mysqli_query($this->db->getDb(), $qry1);
                $stmt2 = mysqli_query($this->db->getDb(), $qry2);
                
                while(($row1 = mysqli_fetch_array($stmt1)) && ($row2 = mysqli_fetch_array($stmt2)) )
                    {
                
                        $json['g1']       = $row1['game_1'];
                        $json['g2']       = $row1['game_2'];
                        $json['g3']       = $row1['game_3'];
                        $json['amt']      = $row1['fees'];
                        $json['status']   = $row1['fees_status'];
                        $json['mode']     = $row1['payment_mode'];
                
                        $json['enrol']    = $row2['enrol_no'];
                        $json['student']  = $row2['student_name'];
                        $json['father']  = $row2['father_name'];
                        $json['gender']  = $row2['gender'];
                        $json['course']  = $row2['course'];
                        $json['year']  = $row2['year'];
                        $json['section']  = $row2['section'];
                        $json['phone_no']  = $row2['phone_no'];
                        $json['email_id']  = $row2['email_id'];
                        
                        $json['success']  = 1;
                        $json['message']  = "Successfull";
                     
                    }
 
            }
 
            else{
                
                $json['success'] = 0;
                $json['message'] = "Enrolment No. Does Not Exists";
            }
             
             mysqli_close($this->db->getDb());
             
            return $json;
     }
     
     //Update Student Payment Status
     
        public function Update_Payment($enrol, $fees_status, $payment_mode)
        {
                
            $query = "update ".$this->db_table2." SET fees_status = '$fees_status', payment_mode = '$payment_mode' where enrol_no = '$enrol' ";

            $updated = mysqli_query($this->db->getDb(), $query);
        
            if($updated == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Successfully Updated";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Update Unsuccessful";
                    
                }
            
            mysqli_close($this->db->getDb());
            
            return $json;
           
        }
        
        // Update Student Details
        public function updatestudentinfo($enrol, $studentname, $fathername, $mobileno, $emailid, $gender, $course, $year, $section, $game1, $game2, $game3, $amount)
        {
                
            $query = "update ".$this->db_table." SET enrol_no = '$enrol', student_name = '$studentname', father_name = '$fathername' , gender = '$gender', course = '$course', year = '$year', section = '$section', phone_no = '$mobileno', email_id = '$emailid' where enrol_no = '$enrol'";

            $query2 ="update ".$this->db_table2." SET enrol_no = '$enrol', game_1 = '$game1', game_2 = '$game2', game_3 = '$game3', fees = '$amount' where enrol_no = '$enrol'";

                $updated = mysqli_query($this->db->getDb(), $query);
                $updated2 = mysqli_query($this->db->getDb(), $query2);

                if(($updated == 1) && ($updated2 == 1)){
                    
                    $json['success'] = 1;
                    $json['message'] = "Successfully Updated";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Updation Unsuccessful";
                    
                }
                
        
            mysqli_close($this->db->getDb());
            
            return $json;
        }
     
     // Student Payment Status
     
      public function fetch_balance_status($game, $status)
        { 
            
            if(!empty($status) && ($game!='Select'))
            {
                $qry = "SELECT ".$this->db_table.".enrol_no, student_name, course, fees FROM ".$this->db_table." INNER JOIN ".$this->db_table2." ON ".$this->db_table.".enrol_no = ".$this->db_table2.".enrol_no where fees_status = '$status' AND (game_1 = '$game' OR game_2 = '$game' OR game_3 = '$game')";
            
                $result = mysqli_query($this->db->getDb(), $qry);
            }
            else
            {
                
                $qry = "SELECT ".$this->db_table.".enrol_no, student_name, course, fees FROM ".$this->db_table." INNER JOIN ".$this->db_table2." ON ".$this->db_table.".enrol_no = ".$this->db_table2.".enrol_no where fees_status = '$status'";
            
                $result = mysqli_query($this->db->getDb(), $qry);
            }
            
            if(mysqli_num_rows($result) >0)
            {
                $json["message"] = "Requested Data";
                $json["data"]    = array();
                
                
            while($arr = mysqli_fetch_assoc($result))
                    {
                        $temp = array();
                        $temp = $arr;
                        
                        array_push($json["data"],$temp);
                    }
                    
            }
            else
            {
                $json["message"] = "No Data Available For Your Selection";
            }
           
                mysqli_close($this->db->getDb());
             
            return $json;
        }
        
        
        //Check Adding of Game in List
        
        public function isGameExist($game){
            
            $query = "select * from ".$this->db_table3." where game_name = '$game'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                mysqli_close($this->db->getDb());
                
                return true;
                
            }
            
            return false;
            
        }
        
        //Adding Game in List
        
        public function add_games ($game, $fees)
        {
            
            $isgame = $this->isGameExist($game);
            
            if($isgame){
                
                $json['success'] = 0;
                $json['message'] = "Error : Game Already Exist";
            }
            
            else{
                
                $query ="insert into ".$this->db_table3." (game_name, fees, date, time) values ('$game', '$fees', 'NA', 'NA')";

                $inserted = mysqli_query($this->db->getDb(), $query);
                
                if($inserted == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Game Saved Successfully";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Submission Unsuccessful";
                    
                }
                
            }
            
            return $json;
        }
        
        // delete Game from List
        
        public function del_games ($game)
        {
                
            $query ="delete from ".$this->db_table3." where game_name = '$game'";

                $inserted = mysqli_query($this->db->getDb(), $query);
                
                if($inserted == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Game Deleted Successfully";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Submission Unsuccessful";
                    
                }
                
            
            return $json;
        }
        
        //Update Games Schedule
        
        public function games_schedule ($game, $date, $time, $venue)
        {
            $query ="update ".$this->db_table3." Set date = '$date', time = '$time', venue = '$venue' where game_name = '$game'";

                $updated = mysqli_query($this->db->getDb(), $query);
                
                if($updated == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Schedule Updated Successfully";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Submission Unsuccessful";
                    
                }
            
            return $json;
        }
        //News image id
        public function news_imageid()
        {
            $json = 0;
            
            $query = "select news_id from ".$this->db_table5." ORDER BY news_id ASC";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            while($row = mysqli_fetch_array($result))
            {
                $json = $row['news_id'];
            }
            
            return $json;
        }
        
        //News Check
        
        public function isheadingExist($head){
            
            $query = "select * from ".$this->db_table5." where heading = '$head'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
               
                return true;
            }
            
            return false;
        }
        //News Details
        
        public function news_details($image, $image_url, $head, $desc, $time){
            
            $path = "https://sportal-ccsit.000webhostapp.com/Android/"."$image_url";
            
            $isheading = $this->isheadingExist($head);
            
            if($isheading){
                
                $json['success'] = 0;
                $json['message'] = "Error : This News is already Exists";
            }
            
            else{
                
                $query = "insert into ".$this->db_table5." (image, heading, description, time) values ('$path', '$head', '$desc', '$time')";

                $inserted = mysqli_query($this->db->getDb(), $query);

                if($inserted == 1){
                    
                    
                    file_put_contents($image_url, $image);
   
                    $json['message'] = "News Uploaded";
                    
                }else{
                    
                    $json['message'] = "Error: News Upload Unsuccessful";
                    
                }
                
            }
            
            return $json;
        }
        
        //Recyler List of Games
        
        public function recycler_game()
        {
            $query ="select * from ".$this->db_table3;

            $list = mysqli_query($this->db->getDb(), $query);
                
                if(mysqli_num_rows($list) > 0){
                    
                    $json["message"] = "Matches Available";
                    $json["data"]    = array();
                
                    while($arr = mysqli_fetch_assoc($list))
                    {
                        $temp = array();
                        $temp = $arr;
                        
                        array_push($json["data"],$temp);
                    }
                    
                }
                else
                {
                    $json["message"] = "No Matches Available";
                }
            return $json;
        }
        
        //Admin Results Check
        
         public function isAdminResultExist($game){
            
            $query = "select * from ".$this->db_table6." where match_name = '$game'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                return true;
                
            }
            
            return false;
        }
        
        //Admin Results
        
        public function AdminResults($game, $winner){
            
            $canAdminResults = $this->isAdminResultExist($game);
            
            if($canAdminResults){
                
                $query  = "Update ".$this->db_table6." Set match_winner = '$winner' where match_name = '$game'";
            
                $updated = mysqli_query($this->db->getDb(), $query);
                
                if($updated == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Results Saved Successully";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Result Submission Unsuccessful";
                    
                }
                
            }else{
                
                $query  = "insert into ".$this->db_table6." (match_name, match_winner) values ('$game','$winner')";
            
                $inserted = mysqli_query($this->db->getDb(), $query);
                
                if($inserted == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Results Saved Successully";
                    
                }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Submission Unsuccessful";
                    
                }
            }
            
            return $json;
        }
        
        //Spinner list of Games
        
        public function spinner()
        {
           
           $json["data"] = array();
           
		    $query = "select game_name from ".$this->db_table3." ORDER BY game_name";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
		    while($val = mysqli_fetch_assoc($result))
		        {
		            $temp = array();
                    $temp = $val;
                        
                    array_push($json["data"],$temp);
		        }
		        
		        return $json;
        }
        
         //Admin Password Check
        
         public function AdmincheckPass($username, $hashed_cpassword){
            
            $query = "select password from ".$this->db_table4." where username = '$username'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            while($row=mysqli_fetch_assoc($result))
            {
                    $pass = $row["password"];
                    
                    if($pass == $hashed_cpassword)
                    {
                     return true;   
                    }
                    else
                    {
                        return false;
                    }
                
            }
            
        }
        
        // Admin Password Change
        
        public function AdminPassChange($hashed_cpassword, $hashed_npassword, $username)
        {
            $AdminPass = $this->AdmincheckPass($username, $hashed_cpassword);
            
            if($AdminPass){
                
                $query  = "UPDATE ".$this->db_table4." SET password = '$hashed_npassword' where username = '$username'";
            
                $updated = mysqli_query($this->db->getDb(), $query);
                
                if($updated == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Password Successfully Changed";
                    
                }
                else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Password Not Changed";
                    
                }
                
            }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Invalid Current Password";
                    
                }
            
            return $json;
        }
        
        //Gallery image id
        public function gallery_imageid()
        {
            $json = 0;
            
            $query = "select gallery_id from ".$this->db_table7." ORDER BY gallery_id ASC";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            while($row = mysqli_fetch_array($result))
            {
                $json = $row['gallery_id'];
            }
            
            return $json;
        }
        
        //Gallery Details
        
        public function gallery_details($image, $image_url){
            
            $path = "https://sportal-ccsit.000webhostapp.com/Android/"."$image_url";
            
                $query = "insert into ".$this->db_table7." (image) values ('$path')";

                $inserted = mysqli_query($this->db->getDb(), $query);

                if($inserted == 1){
                    
                    
                    file_put_contents($image_url, $image);
   
                    $json['message'] = "Image Uploaded";
                    
                }else{
                    
                    $json['message'] = "Error: Image Upload Unsuccessful";
                    
                }
            
            return $json;
        }
        
        
 //--------------------------------------------Student Sportal ------------------------------------------------------       
        //Student Login Check
        
         public function isStudentLoginExist($username, $password){
            
            $query = "select * from ".$this->db_table." where enrol_no = '$username' AND password = '$password'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                return true;
                
            }
            
            mysqli_close($this->db->getDb());
            
            return false;
            
        }
        
        //Student Login
        
         public function loginStudent($username, $password){
             
            
            $canLogin = $this->isStudentLoginExist($username, $password);
            
            if($canLogin){
                
                $query  = "select student_name from ".$this->db_table." where enrol_no = '$username'";
            
                $result = mysqli_query($this->db->getDb(), $query);
                
                $row    = mysqli_fetch_assoc($result);
                
                $json['name']    = $row['student_name'];
                $json['success']  = 1;
                $json['message']  = "Successfully Logged In";
                        
            }
 
            else{
                
                $json['success'] = 0;
                $json['message'] = "Invalid Username or Password";
            }
             
             
            return $json;
        }
        
        
        //Student MyGames Check
        
        public function isStudentGamesExist($enrol){
            
            $query = "select * from ".$this->db_table2." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                return true;
                
            }
            
            return false;
            
        }
         
         //Game Name
        
        public function GameName($enrol, $i){
            
            $query = "select game_".$i." from ".$this->db_table2." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
             
            $gm =  mysqli_fetch_assoc($result);
            
            return $gm;
        }
        
        //Student Name
        
        public function StudentName($enrol){
            
            $query = "select student_name from ".$this->db_table." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
             
            $sname =  mysqli_fetch_assoc($result);
            
            return $sname;
        }
        
        //Game Schedule
        
        public function GameSchedule($game){
            
            $query = "select date, time, venue from ".$this->db_table3." where game_name = '$game'";
            
            $result = mysqli_query($this->db->getDb(), $query);
             
            $sname =  mysqli_fetch_assoc($result);
            
            return $sname;
        }

        // Student MyGames
        
        public function StudentGames($enrol){
            
            $haveGames = $this->isStudentGamesExist($enrol);
            
            if($haveGames){
            
                        $json['message'] = "Data Available";
                        
                        $snm = $this->StudentName($enrol);
                        $json['st_name'] = $snm['student_name'];
                        
                        $game = $this->GameName($enrol, 1);
                        $gm1  = $game['game_1']; 
                        
                        $game = $this->GameName($enrol, 2);
                        $gm2  = $game['game_2'];
                        
                        $game = $this->GameName($enrol, 3);
                        $gm3  = $game['game_3'];
                        
                         if($gm1 != "")
                        {
                            $sched = $this->GameSchedule($gm1);
                            $json['g1'] = $gm1; 
                            $json['d1'] = $sched['date'];
                            $json['t1'] = $sched['time'];
                            $json['v1'] = $sched['venue'];
                        }
                        else
                        {
                            $json['g1'] = ""; 
                            $json['d1'] = "";
                            $json['t1'] = "";
                            $json['v1'] = "";
                        
                        }
                        
                        if($gm2 != "")
                        {
                            $sched = $this->GameSchedule($gm2);
                            $json['g2'] = $gm2; 
                            $json['d2'] = $sched['date'];
                            $json['t2'] = $sched['time'];
                            $json['v2'] = $sched['venue'];
                        
                        }
                        else
                        {
                            $json['g2'] = ""; 
                            $json['d2'] = "";
                            $json['t2'] = "";
                            $json['v2'] = "";
                        
                        }
                        
                        if($gm3 != "")
                        {
                            $sched = $this->GameSchedule($gm3);
                            $json['g3'] = $gm3; 
                            $json['d3'] = $sched['date'];
                            $json['t3'] = $sched['time'];
                            $json['v3'] = $sched['venue'];
                        
                        }
                        else
                        {
                            $json['g3'] = ""; 
                            $json['d3'] = "";
                            $json['t3'] = "";
                            $json['v3'] = "";
                        
                        }
                    
                }
 
            else{
                
                $json['success'] = 0;
                $json['message'] = "No Participation from your side";
            }
             
            return $json;
        }
        
        //Student Balance
        
        public function StudentBalance($enrol)
        {
            $haveGames = $this->isStudentGamesExist($enrol);
            
            if($haveGames){
            
                $query1 = "select student_name from ".$this->db_table." where enrol_no = '$enrol'";
                $query2 = "select * from ".$this->db_table2." where enrol_no = '$enrol'";
                
                $result1 = mysqli_query($this->db->getDb(), $query1);
                $result2 = mysqli_query($this->db->getDb(), $query2);
                
            
		            while(($row1 = mysqli_fetch_array($result1)) && ($row2 = mysqli_fetch_array($result2)))
		            {
		                $json['message'] = "Data Available";
		                $json['st_name'] = $row1['student_name'];
		                $json['game1']   = $row2['game_1'];
		                $json['game2']   = $row2['game_2'];
		                $json['game3']   = $row2['game_3'];
		                $json['fees']    = $row2['fees'];
		                $json['status']  = $row2['fees_status'];
		                $json['mode']    = $row2['payment_mode'];
		             
                    }
                    
                }
 
            else{
                
                $json['success'] = 0;
                $json['message'] = "No Participation from your side";
            }
             
            return $json;    
        }
        
        //Upcoming Games
        
        public function upcoming_games()
        {
            $query ="select * from ".$this->db_table3." where NOT date = 'NA'";

            $list = mysqli_query($this->db->getDb(), $query);
                
                if(mysqli_num_rows($list) > 0){
                    
                    $json["message"] = "Matches Available";
                    $json["data"]    = array();
                
                    while($arr = mysqli_fetch_assoc($list))
                    {
                        $temp = array();
                        $temp = $arr;
                        
                        array_push($json["data"],$temp);
                    }
                    
                }
                else
                {
                    $json["message"] = "No Matches Available";
                }
            return $json;
        }
        
        //Fetch News
        
        public function StudentNews()
        {

		    $query = "select * from ".$this->db_table5." order by news_id desc";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
             if(mysqli_num_rows($result) >0)
             {
            
               $json["message"] = "News Available";     
               $json["data"]    = array();
           
            
		    while($val = mysqli_fetch_assoc($result))
		        {
		            $temp = array();
                    $temp = $val;
                        
                    array_push($json["data"],$temp);
		        }
		        
             }
             else
             {
                 $json["message"] = "No News Available";
             }
		        return $json;
        }
        
        //Fetch Gallery
        
        public function Gallery()
        {

		    $query = "select * from ".$this->db_table7." order by gallery_id desc";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
             if(mysqli_num_rows($result) >0)
             {
            
               $json["message"] = "Gallery Images Available";     
               $json["data"]    = array();
           
            
		    while($val = mysqli_fetch_assoc($result))
		        {
		            $temp = array();
                    $temp = $val;
                        
                    array_push($json["data"],$temp);
		        }
		        
             }
             else
             {
                 $json["message"] = "No Images Available";
             }
		        return $json;
        }
        
        //Student Result
         
         public function StudentResult()
        {

		    $query = "select * from ".$this->db_table6;
            
            $result = mysqli_query($this->db->getDb(), $query);
            
             if(mysqli_num_rows($result) >0)
             {
            
               $json["message"] = "Result Available";     
               $json["data"]    = array();
           
            
		    while($val = mysqli_fetch_assoc($result))
		        {
		            $temp = array();
                    $temp = $val;
                        
                    array_push($json["data"],$temp);
		        }
		        
             }
             else
             {
                 $json["message"] = "No Result Available";
             }
		        return $json;
        }
        
        //OTP Verification
        
        public function OTPEnrolCheck($enrol){
            
            $query = "select phone_no from ".$this->db_table." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
               $row             = mysqli_fetch_assoc($result);
               $json['message'] = "Enrol Available";
               $json['mobile']  = $row["phone_no"];
 
            }
            else
            {
                $json['message'] = "Enrolment Number Not Registered";
            }
            
            return $json;
        }
        
        //Student Password Check
        
         public function StudentcheckPass($enrol, $hashed_cpassword){
            
            $query = "select password from ".$this->db_table." where enrol_no = '$enrol'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            while($row=mysqli_fetch_assoc($result))
            {
                    $pass = $row["password"];
                    
                    if($pass == $hashed_cpassword)
                    {
                     return true;   
                    }
                    else
                    {
                        return false;
                    }
                
            }
            
        }
        
        // Student Password Change
        
        public function StudentPassChange($hashed_cpassword, $hashed_npassword, $enrol)
        {
            $StudentPass = $this->StudentcheckPass($enrol, $hashed_cpassword);
            
            if($StudentPass){
                
                $query  = "UPDATE ".$this->db_table." SET password = '$hashed_npassword' where enrol_no = '$enrol'";
            
                $updated = mysqli_query($this->db->getDb(), $query);
                
                if($updated == 1){
                    
                    $json['success'] = 1;
                    $json['message'] = "Password Successfully Changed";
                    
                }
                else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Error: Password Not Changed";
                    
                }
                
            }else{
                    
                    $json['success'] = 0;
                    $json['message'] = "Invalid Current Password";
                    
                }
            
            return $json;
        }
    }    
    ?>